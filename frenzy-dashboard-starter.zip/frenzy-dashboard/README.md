# FRENZY Owner Dashboard

Static, mobile-friendly starter dashboard for FRENZY ($FRNZ).

## Deploy on Render
1. Upload `index.html` and `README.md` to the `main` branch of `lakersin657-design/frenzy-dashboard`.
2. In Render, create a **Static Site** and connect that repository.
3. Leave Build Command blank (or use `echo "Static site"` if required).
4. Set Publish Directory to `.` and deploy.

## Status
This is a UI starter. Live market data, wallet connection, Solana RPC/indexer, treasury actions, liquidity tracking, and token creation are not configured. No on-chain token has been created by this project. All on-chain actions must require wallet approval and public transaction disclosure.
